def GlobalMethod  ( (a,b) ,p = a.b) :
    '''GlobalMethod docs'''
    
