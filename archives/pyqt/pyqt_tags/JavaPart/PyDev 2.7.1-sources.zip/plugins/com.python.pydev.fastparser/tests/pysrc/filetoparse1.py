def GlobalMethod(param1):
    '''GlobalMethod docs'''