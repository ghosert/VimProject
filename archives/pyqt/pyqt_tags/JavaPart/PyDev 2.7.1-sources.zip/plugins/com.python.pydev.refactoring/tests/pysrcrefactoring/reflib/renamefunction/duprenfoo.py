

def RenFoo(a):
    pass

print RenFoo