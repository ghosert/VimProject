from duprenfoo import RenFoo

print RenFoo