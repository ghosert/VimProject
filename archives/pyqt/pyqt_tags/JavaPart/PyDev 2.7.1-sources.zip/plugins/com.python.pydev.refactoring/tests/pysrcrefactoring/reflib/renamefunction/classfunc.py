class Foo(object):
    def mmm(self):
        pass
f = Foo()
f.mmm()
