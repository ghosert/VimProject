class Definition(object):
    pass