from renfoo import RenFoo


print RenFoo
#Comment: RenFoo
'String:RenFoo'

