/**
 * Copyright (c) 2005-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Eclipse Public License (EPL).
 * Please see the license.txt included with this distribution for details.
 * Any modifications to this file must keep this entire header intact.
 */
/*
 * Created on 25/06/2005
 */
package org.python.pydev.ast.management;

/**
 * This is the interface that is provided for managing asts through the projects.
 * 
 * @author Fabio
 */
public interface IASTManager {

}
