# The root bicyclerepairman package
# do:
# ---------------------
# import bike
# ctx = bike.load()
# ---------------------
# to instantiate a bicyclerepairman context object


from bikefacade import init, NotAPythonModuleOrPackageException, CouldntLocateASTNodeFromCoordinatesException, UndoStackEmptyException
