class Class1(object):
    'Class1 docs'