def GlobalMethod  ( param1 ,  #comment
                    param2    #comment
                    ,p = 10,   #comment
                    *args,
                    **kwargs
                   )  :       #comment
    '''GlobalMethod docs'''
    
def GlobalMethod2 ( p = 10,   #comment
                    u = "30",
                    *args   ,
                    **kwargs
                   )  :       #comment
    '''GlobalMethod docs'''