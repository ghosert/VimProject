package com.python.pydev.refactoring;

public class CancelProgressException extends Exception {

}
