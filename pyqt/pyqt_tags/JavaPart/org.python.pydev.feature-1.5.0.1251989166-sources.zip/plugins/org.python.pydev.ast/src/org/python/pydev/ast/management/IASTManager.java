/*
 * Created on 25/06/2005
 */
package org.python.pydev.ast.management;

/**
 * This is the interface that is provided for managing asts through the projects.
 * 
 * @author Fabio
 */
public interface IASTManager {

}
