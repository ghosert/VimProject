package org.python.pydev.core.docutils;

public class ImportNotRecognizedException extends Exception {

    public ImportNotRecognizedException(String msg) {
        super(msg);
    }

}
