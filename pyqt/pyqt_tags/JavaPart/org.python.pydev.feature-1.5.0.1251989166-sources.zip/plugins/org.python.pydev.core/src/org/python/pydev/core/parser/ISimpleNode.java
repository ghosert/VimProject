package org.python.pydev.core.parser;

/**
 * Just documentational (for places where we don't have access to the actual SimpleNode class)
 * 
 * @author Fabio
 */
public interface ISimpleNode {

}
