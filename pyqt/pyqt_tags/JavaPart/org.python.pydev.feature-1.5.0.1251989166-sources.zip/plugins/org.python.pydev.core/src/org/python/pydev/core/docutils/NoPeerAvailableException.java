package org.python.pydev.core.docutils;

public class NoPeerAvailableException extends RuntimeException {

    public NoPeerAvailableException(String message) {
        super(message);
    }

}
