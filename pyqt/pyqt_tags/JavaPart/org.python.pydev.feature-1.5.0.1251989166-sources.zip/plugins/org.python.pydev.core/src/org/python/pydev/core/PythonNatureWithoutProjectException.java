package org.python.pydev.core;

public class PythonNatureWithoutProjectException extends Exception{

    public PythonNatureWithoutProjectException(String msg) {
        super(msg);
    }

    private static final long serialVersionUID = 3991274611104226229L;

}
