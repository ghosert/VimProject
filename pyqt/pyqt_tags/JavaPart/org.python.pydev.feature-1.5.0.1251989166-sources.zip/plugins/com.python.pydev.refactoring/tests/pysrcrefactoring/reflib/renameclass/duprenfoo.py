

class RenFoo(object):
    pass

print RenFoo