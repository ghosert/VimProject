import mod1
from mod1 import submod1
#mod1 comment
'mod1 string'