class RenameSelfClass(object):
    def __init__(self):
        self.instance1 = 1
        self.instance2 = 1
        #instance1 comment
        'instance1 string'
