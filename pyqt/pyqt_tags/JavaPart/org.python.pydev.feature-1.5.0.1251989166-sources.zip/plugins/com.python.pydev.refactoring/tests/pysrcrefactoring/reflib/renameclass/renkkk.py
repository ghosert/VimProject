class ActionProvider(object):
    
    def SlotImportSimulation(cls):
        ActionProvider()._DoSlotImportSimulation()

