class Foo(object):
    def mm(self, barparam):
        '''
            @param barparam: this is barparam
        '''
f = Foo()
f.mm(barparam=10)
