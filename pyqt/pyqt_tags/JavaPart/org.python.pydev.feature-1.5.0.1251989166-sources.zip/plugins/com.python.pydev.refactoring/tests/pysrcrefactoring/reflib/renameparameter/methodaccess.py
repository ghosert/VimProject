from methoddef import Method1
Method1(10, param2=20)
Method1(param1=10, param2=20)
param1=50
Method1(param1=param1, param2=20)
