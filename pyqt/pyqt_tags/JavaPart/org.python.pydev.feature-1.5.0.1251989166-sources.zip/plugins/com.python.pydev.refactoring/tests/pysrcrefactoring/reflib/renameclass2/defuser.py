from sub1 import Definition

print Definition