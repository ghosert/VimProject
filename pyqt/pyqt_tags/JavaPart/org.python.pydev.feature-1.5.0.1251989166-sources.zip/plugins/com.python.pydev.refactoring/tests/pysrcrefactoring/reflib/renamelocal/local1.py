def method():
    aa = 10
    print aa