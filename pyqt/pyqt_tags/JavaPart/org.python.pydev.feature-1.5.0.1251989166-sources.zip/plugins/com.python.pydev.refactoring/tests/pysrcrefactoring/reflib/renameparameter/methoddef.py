param1 = 10 #should not be gotten
def Method1(param1=param1, param2=None):
    print param1, param2