def RenFoo():
    pass

print RenFoo
'String with RenFoo'
#comment with RenFoo
