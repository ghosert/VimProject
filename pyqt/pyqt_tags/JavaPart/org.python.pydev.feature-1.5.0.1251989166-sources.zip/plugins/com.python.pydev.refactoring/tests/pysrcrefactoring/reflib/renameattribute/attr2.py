def m1(a):
    a.attrInstance = 10
    #attrInstance comment
    'attrInstance comment'