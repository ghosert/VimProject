class Definition(object):
    pass