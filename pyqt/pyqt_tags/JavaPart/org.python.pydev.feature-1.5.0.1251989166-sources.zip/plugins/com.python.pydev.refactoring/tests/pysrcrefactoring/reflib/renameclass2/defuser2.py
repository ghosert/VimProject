from defuser import Definition

print Definition