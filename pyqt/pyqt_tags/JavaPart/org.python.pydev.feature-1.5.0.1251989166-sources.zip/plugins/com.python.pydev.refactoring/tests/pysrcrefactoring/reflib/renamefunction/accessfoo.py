from renfoo import RenFoo


print RenFoo
#comment access RenFoo
'''
    RenFoo access
'''
